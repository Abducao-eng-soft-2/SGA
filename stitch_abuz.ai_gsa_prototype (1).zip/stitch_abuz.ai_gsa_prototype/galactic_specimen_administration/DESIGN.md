---
name: Galactic Specimen Administration
colors:
  surface: '#0f131d'
  surface-dim: '#0f131d'
  surface-bright: '#353944'
  surface-container-lowest: '#0a0e17'
  surface-container-low: '#171c25'
  surface-container: '#1b2029'
  surface-container-high: '#262a34'
  surface-container-highest: '#31353f'
  on-surface: '#dfe2f0'
  on-surface-variant: '#bac9cc'
  inverse-surface: '#dfe2f0'
  inverse-on-surface: '#2c303b'
  outline: '#849396'
  outline-variant: '#3b494c'
  surface-tint: '#00daf3'
  primary: '#c3f5ff'
  on-primary: '#00363d'
  primary-container: '#00e5ff'
  on-primary-container: '#00626e'
  inverse-primary: '#006875'
  secondary: '#aec6ff'
  on-secondary: '#002e6b'
  secondary-container: '#508eff'
  on-secondary-container: '#00275e'
  tertiary: '#dbf0ff'
  on-tertiary: '#00354a'
  tertiary-container: '#99d9ff'
  on-tertiary-container: '#006083'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#9cf0ff'
  primary-fixed-dim: '#00daf3'
  on-primary-fixed: '#001f24'
  on-primary-fixed-variant: '#004f58'
  secondary-fixed: '#d8e2ff'
  secondary-fixed-dim: '#aec6ff'
  on-secondary-fixed: '#001a43'
  on-secondary-fixed-variant: '#004397'
  tertiary-fixed: '#c4e7ff'
  tertiary-fixed-dim: '#7bd0ff'
  on-tertiary-fixed: '#001e2c'
  on-tertiary-fixed-variant: '#004c69'
  background: '#0f131d'
  on-background: '#dfe2f0'
  surface-variant: '#31353f'
typography:
  display-hero:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-hero-mobile:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: 0em
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: 0em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.01em
  code-id:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.04em
  telemetry-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.06em
  classification-tag:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 12px
    letterSpacing: 0.12em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
---

## Brand & Style

The design system establishes a high-tier extraterrestrial administrative console—clean, highly technical, and cold. Tailored for interstellar research command, scientific cataloging, and administrative oversight, it balances classified mission management with pristine academic rigour.

The aesthetic fuses **Modern Sci-Fi Minimalist** with **Technical Glassmorphism**:
- Deep void backdrops with frosted crystalline panels.
- Micro-fine cyan luminous edges simulating heads-up tactical interfaces without visual clutter.
- Prominent operational telemetry, precise spatial coordinates, and strict classification metadata.
- All non-operational views enforce an explicit classification stamp: `[DADOS DEMONSTRATIVOS - DISCOVERY]` anchored to headers, footers, and floating telemetry indicators.

## Colors

The palette operates in high-contrast deep space darkness, punctuated by precise quantum luminescence.

### Base Surface Architecture
- **Cosmic Void (Canvas):** `#070b14`
- **Sub-orbital Surface (Nav / Card Tiers):** `#0b1329` with layered translucency (`rgba(11, 19, 41, 0.75)`).
- **Elevated Crystalline Overlay:** `rgba(15, 23, 42, 0.60)` with thin structural borders (`rgba(0, 229, 255, 0.18)`).

### Accents & Signal Optics
- **Primary Energy (Cyan Glow):** `#00e5ff` — used for telemetry pings, critical indicators, and active primary controls.
- **Sub-Primary Vector (Deep Warp Blue):** `#0070f3` — structural actions and secondary system highlights.
- **Atmospheric Highlight (Sky Neon):** `#38bdf8` — hover states and tactical sub-labels.

### Readout & Typography
- **Command Text (Pure Starlight):** `#f8fafc` — high-priority readouts, primary headers, specimen counts.
- **Telemetry Gray (Silver Asteroid):** `#94a3b8` — secondary metadata, labels, and dimensional units.
- **De-emphasized Grid Text:** `#475569` — non-essential guidelines, frame timestamps.

### Mission Status Matrix
- **Em Andamento (In Progress):** Cyan/Blue pulse — Text: `#38bdf8`, Surface: `rgba(56, 189, 248, 0.12)`, Border: `rgba(56, 189, 248, 0.4)`.
- **Aguardando Autorização (Awaiting Clearance):** Amber solar flare — Text: `#fbbf24`, Surface: `rgba(251, 191, 36, 0.12)`, Border: `rgba(251, 191, 36, 0.4)`.
- **Temporariamente Cancelado (Suspended):** Deep cadmium alert — Text: `#fb923c`, Surface: `rgba(251, 146, 60, 0.12)`, Border: `rgba(251, 146, 60, 0.4)`.
- **Cancelado Definitivo (Aborted):** High-density red alert — Text: `#f43f5e`, Surface: `rgba(244, 63, 94, 0.12)`, Border: `rgba(244, 63, 94, 0.4)`.
- **Concluído (Concluded):** Stable emerald vector — Text: `#34d399`, Surface: `rgba(52, 211, 153, 0.12)`, Border: `rgba(52, 211, 153, 0.4)`.

## Typography

The typographical structure leverages dual font engines:
- **Inter** provides high-precision legibility for universal administration interfaces, forms, table content, and system dialogues.
- **JetBrains Mono** manages high-density readouts, planetary coordinates, specimen serial numbers (e.g., `SP-TERRA-8492`), timestamps, and categorical status indicators.

### Rules
- All classification markers and tags must render in uppercase via `JetBrains Mono` with loose letter-spacing (`0.12em`).
- Numeric metrics and tabular coordinates must apply tabular figures (`tnum`) to eliminate spatial jitter during real-time data streaming.

## Layout & Spacing

A unified 12-column adaptive fluid matrix powers both command consoles and mobile telemetry docks.

### Grid & Breakpoints
- **Mobile (< 768px):** 4 columns, `margin`: `1rem`, `gutter`: `1rem`. Panels stack vertically into full-width telemetry cards.
- **Tablet (768px - 1024px):** 8 columns, `margin`: `1.5rem`, `gutter`: `1rem`. Multi-parameter splits enabled.
- **Desktop / Command Station (> 1024px):** 12 columns with max container width of `1600px`, `margin`: `2.5rem`, `gutter`: `1.5rem`. Enables persistent left telemetry navigation, central mission map/table, and right contextual diagnostic panel.

### Spatial Discipline
All interior padding adheres to strict 8pt base units (`0.5rem`, `1rem`, `1.5rem`), maintaining architectural rigidity common to professional flight decks.

## Elevation & Depth

Visual depth does not use heavy traditional drop shadows; instead, it relies on optical luminosity and physics-based light refraction against dark matter surfaces.

### Surface Tiers
1. **Tier 0 (Deep Space Vacuum):** `#070b14` — raw base background, non-interactive.
2. **Tier 1 (Sub-glass Matrix):** Translucent `#0b1329` at 75% opacity, backdrop filter `blur(12px)`. Enclosed by a 1px continuous border of `rgba(255, 255, 255, 0.06)`.
3. **Tier 2 (Tactical Glass Modals & Selected Cards):** Translucent `#0f1b35` at 85% opacity, backdrop filter `blur(20px)`. Defined by a 1px border of `rgba(0, 229, 255, 0.25)`.
4. **Tier 3 (Active Focus / Critical Overlays):** Border glows using a dual cyan drop-shadow: `0 0 1px #00e5ff, 0 0 16px rgba(0, 229, 255, 0.20)`.

### Ambient Radiance
Interactive components emit localized soft neon halos upon cursor or focus alignment, producing an energized, capacitive terminal effect.

## Shapes

The interface embraces a restrained, industrial bevel curvature (`roundedness: 1` — base radius of `0.25rem` / `4px`). 

- Standard inputs, buttons, and telemetry cells feature subtle 4px radiuses to retain an engineered instrument feel.
- Glass panels and containment cards use `rounded-lg` (`0.5rem` / `8px`).
- Badges and status pills leverage micro-capsule radiuses (`rounded-xl` / `12px` or full rounded corners) to differentiate discrete classification tokens from angular structural components.

## Components

### 1. Mission Status Badges
Status indicators must render as luminous capsule chips featuring an animated breathing dot (ping) on active states:
- **Structure:** `border-radius: 9999px`, height `24px`, horizontal padding `0.75rem`.
- **Typography:** `JetBrains Mono`, 10px, weight 700, tracking `0.1em`.
- **States:**
  - *Em Andamento:* Cyan border `rgba(0, 229, 255, 0.5)`, background `rgba(0, 229, 255, 0.1)`, text `#00e5ff`, animated radial pulse dot.
  - *Aguardando Autorização:* Amber border `rgba(251, 191, 36, 0.5)`, background `rgba(251, 191, 36, 0.1)`, text `#fbbf24`.
  - *Temporariamente Cancelado:* Orange border `rgba(251, 146, 60, 0.5)`, background `rgba(251, 146, 60, 0.1)`, text `#fb923c`.
  - *Cancelado Definitivo:* Rose border `rgba(244, 63, 94, 0.5)`, background `rgba(244, 63, 94, 0.1)`, text `#f43f5e`.
  - *Concluído:* Emerald border `rgba(52, 211, 153, 0.5)`, background `rgba(52, 211, 153, 0.1)`, text `#34d399`.

### 2. Buttons
- **Primary Control:** Solid fill `#00e5ff` text `#070b14` (`Inter` 600). Hover state blooms an energetic halo (`box-shadow: 0 0 16px rgba(0, 229, 255, 0.5)`).
- **Secondary / HUD Button:** Background `rgba(11, 19, 41, 0.8)`, border `1px solid rgba(0, 229, 255, 0.3)`, text `#f8fafc`. Hover switches border to solid `#00e5ff` with text color tint.
- **Destructive Action:** Background `rgba(244, 63, 94, 0.1)`, border `1px solid rgba(244, 63, 94, 0.4)`, text `#f43f5e`.

### 3. Glassmorphic Data Cards
Constructed from dark frosted glass (`rgba(11, 19, 41, 0.75)`, blur `12px`). Cards have an upper hairline highlight (`border-top: 1px solid rgba(0, 229, 255, 0.2)`) and muted side/bottom contours (`border: 1px solid rgba(255, 255, 255, 0.05)`). Contains a discrete micro-label in the upper-right corner denoting sector, specimen index, or clearance level.

### 4. Input Fields & Selectors
- **Background:** High-clarity void `rgba(7, 11, 20, 0.8)`.
- **Border:** `1px solid rgba(148, 163, 184, 0.2)`.
- **Focus:** Crisp outline `1px solid #00e5ff` with faint cyan intake glow (`box-shadow: 0 0 8px rgba(0, 229, 255, 0.25)`).
- **Typography:** `Inter` for user input; prefix/suffix icons and measurement units in `JetBrains Mono` (`#94a3b8`).

### 5. Checkboxes & Radio Controls
Custom angular check matrices (radius `2px`). Unchecked states use `1px solid rgba(148, 163, 184, 0.4)` over a dark void. Checked state fills with `#00e5ff`, utilizing `#070b14` for check glyphs, creating maximum optical punch.

### 6. Academic Telemetry Banner (Demonstrative Marker)
- Anchored to the persistent application header and specimen inspector headers:
  - Text: `[DADOS DEMONSTRATIVOS - DISCOVERY]`
  - Spec: `JetBrains Mono`, 10px, weight 700, `#38bdf8`, background `rgba(56, 189, 248, 0.08)`, border `1px solid rgba(56, 189, 248, 0.3)`, letter-spacing `0.14em`.